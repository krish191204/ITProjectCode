const products = [
    { id: 1, name: 'Organic Apples', price: 4.99, unit: 'lb', image: 'apple.png' },
    { id: 2, name: 'Fresh Bananas', price: 1.99, unit: 'lb', image: 'banana.png' },
    { id: 3, name: 'Organic Carrots', price: 2.49, unit: 'lb', image: 'carrot2.png' },
    { id: 4, name: 'Free-Range Eggs', price: 3.99, unit: 'dozen', image: 'egg.png' },
    { id: 5, name: 'Tomato', price: 3.50, unit: '', image: 'tomato.png' },
    { id: 6, name: 'Organic Onion', price: 2.50, unit: '', image: 'onion.png'},
    { id: 7, name: 'Cheese', price: 5.00, unit: '', image: 'cheese.png' },
    {id: 8, name: 'Brocolli', price: 2.49, unit: '' ,image: 'brocolli.png'},
    {id: 9, name: '1L Milk Carton', price: 3.50, unit: '', image: 'milk.png' },
    {id: 10, name: 'Potato', price: 2.50, unit: '', image: 'potato.png'}
];


let cart = [];

function addToCart(productId, quantity = 1) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const existingItem = cart.find(item => item.id === productId);
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({...product, quantity});
    }
    updateCart();
    saveCart();
    showCartNotification();
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCart();
    saveCart();
}

function updateQuantity(productId, newQuantity) {
    if (newQuantity < 1) return;
    
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity = newQuantity;
        updateCart();
        saveCart();
    }
}

function updateCart() {
    const cartList = document.querySelector('.cart-items');
    const totalElement = document.querySelector('.cart-total span');
    
    if (cartList && totalElement) {
        cartList.innerHTML = '';
        let total = 0;
        
        if (cart.length === 0) {
            cartList.innerHTML = '<p>Your cart is empty</p>';
            totalElement.textContent = '$0.00';
            return;
        }
        
        cart.forEach(item => {
            const itemTotal = item.price * item.quantity;
            total += itemTotal;
            
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <div class="item-details">
                    <h3>${item.name}</h3>
                    <p>${item.unit ? `Per ${item.unit}` : ''}</p>
                    <div class="item-controls">
                        <button class="quantity-btn" onclick="updateQuantity(${item.id}, ${item.quantity - 1})">-</button>
                        <input type="number" min="1" value="${item.quantity}" 
                               onchange="updateQuantity(${item.id}, parseInt(this.value))" class="quantity-input">
                        <button class="quantity-btn" onclick="updateQuantity(${item.id}, ${item.quantity + 1})">+</button>
                        <span class="price">$${(itemTotal).toFixed(2)}</span>
                    </div>
                </div>
                <button class="remove-btn" onclick="removeFromCart(${item.id})">
                    <i class="fas fa-times"></i>
                </button>
            `;
            cartList.appendChild(cartItem);
        });
        
        totalElement.textContent = `$${total.toFixed(2)}`;
    }
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function loadCart() {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        updateCart();
    }
}

function showCartNotification() {
    const notification = document.createElement('div');
    notification.className = 'cart-notification';
    notification.textContent = 'Item added to cart!';
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 2000);
}


document.addEventListener('DOMContentLoaded', () => {
    loadCart();
    
    
    document.querySelectorAll('.product .btn').forEach(button => {
        button.addEventListener('click', function() {
            const productId = parseInt(this.getAttribute('data-id'));
            addToCart(productId);
        });
    });
    
    
    document.querySelector('.cart a').addEventListener('click', function(e) {
        if (cart.length === 0) {
            e.preventDefault();
            alert('Your cart is empty. Add some items first!');
        }
    });
});


window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateQuantity = updateQuantity;